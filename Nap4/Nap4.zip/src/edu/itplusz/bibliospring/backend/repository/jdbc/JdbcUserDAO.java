package edu.itplusz.bibliospring.backend.repository.jdbc;

import edu.itplusz.bibliospring.backend.model.User;
import edu.itplusz.bibliospring.backend.repository.UserDAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JdbcUserDAO implements UserDAO {
    @Override
    public User findById(Long id) {
        Connection conn = null;
        try {
            conn = ConnectionManager.getInstance().getConnection();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE id=?");
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            rs.next();
            User user = new User();
            user.setId(rs.getLong("id"));
            user.setUsername(rs.getString("username"));
            user.setPassword(rs.getString("password"));
            user.setUuid(rs.getString("uuid"));
            return user;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            ConnectionManager.getInstance().returnConnection(conn);
        }
    }

    @Override
    public User create(User user) {
        Connection conn = null;
        try {
            conn = ConnectionManager.getInstance().getConnection();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO users(username,password,uuid) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getUuid());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            rs.next();
            user.setId(rs.getLong(1));
            return user;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            ConnectionManager.getInstance().returnConnection(conn);
        }

    }

    @Override
    public void update(User user) {

    }

    @Override
    public void delete(User user) {

    }

    @Override
    public List<User> findAll() {
        Connection conn = null;
        List<User> users = new ArrayList<>();
        try{
            conn = ConnectionManager.getInstance().getConnection();
            Statement statement=conn.createStatement();
            ResultSet rs=statement.executeQuery("SELECT * FROM users");
            while(rs.next()){
                User user = new User();
                user.setId(rs.getLong("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setUuid(rs.getString("uuid"));
                users.add(user);
            }
            return users;

        }catch(SQLException e){
            throw new RuntimeException(e);
        }finally{
            ConnectionManager.getInstance().returnConnection(conn);
        }
    }

    @Override
    public User findByUsername(String username) {
        Connection conn = null;
        try {
            conn = ConnectionManager.getInstance().getConnection();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE username=?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            rs.next();
            User user = new User();
            user.setId(rs.getLong("id"));
            user.setUsername(rs.getString("username"));
            user.setPassword(rs.getString("password"));
            user.setUuid(rs.getString("uuid"));
            return user;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            ConnectionManager.getInstance().returnConnection(conn);
        }
    }
}
