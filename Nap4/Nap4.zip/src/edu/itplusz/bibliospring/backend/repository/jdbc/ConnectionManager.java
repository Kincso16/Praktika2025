package edu.itplusz.bibliospring.backend.repository.jdbc;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class ConnectionManager {
    private final int POOL_SIZE=10;
    private LinkedList<Connection> pool;
    private static ConnectionManager instance;

    private ConnectionManager() {
        pool = new LinkedList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            for (int i = 0; i < 10; i++) {
                pool.add(DriverManager.getConnection("jdbc:mysql://localhost:3307/bibliospring","root","alma"));
            }
            System.out.println("pool initialized successfully");
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public synchronized static ConnectionManager getInstance() {
        if (instance == null) {
            instance = new ConnectionManager();
        }
        return instance;
    }

    public Connection getConnection() {
        if (!pool.isEmpty()) {
            return pool.pop();
        }
        return null;
    }

    public void returnConnection(Connection connection) {
        if (pool.size() < POOL_SIZE) {
            pool.push(connection);
        }
    }
}
